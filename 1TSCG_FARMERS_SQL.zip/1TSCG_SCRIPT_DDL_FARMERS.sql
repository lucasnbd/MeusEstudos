/*
    1TSCG - SCRIPT_DDL  - FARMERS
    
    GABRIEL DE OLIVEIRA ANTONIETTE - RM99854 
    GABRIEL DE SOUZA DENTE - RM550796 
    LEANDRO DIAS VIEIRA - RM550997
    LUCAS NAKANISHI BECK DEPIERI - RM552092
    SILVIA LIMA CARNEIRO ARAUJO - RM98833
*/

/*
    DROP TABLE t_sp2_financiamento CASCADE CONSTRAINTS;
    DROP TABLE t_sp2_fonte_recurso CASCADE CONSTRAINTS;
    DROP TABLE t_sp2_modalidade CASCADE CONSTRAINTS;
    DROP TABLE t_sp2_pessoa_fisica CASCADE CONSTRAINTS;
    DROP TABLE t_sp2_pessoa_juridica CASCADE CONSTRAINTS;
    DROP TABLE t_sp2_produto CASCADE CONSTRAINTS;
    DROP TABLE t_sp2_programa CASCADE CONSTRAINTS;
    DROP TABLE t_sp2_solicitante CASCADE CONSTRAINTS;
*/

-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

-- predefined type, no DDL - XMLTYPE


CREATE TABLE t_sp2_financiamento (
    cd_fonte_recurso      NUMBER(4)     NOT NULL,
    cd_financiamento      NUMBER(10)    NOT NULL,
    cd_solicitante        NUMBER(10)    NOT NULL,
    cd_produto            NUMBER(4)     NOT NULL,
    qt_area_finaciada     NUMBER(20, 2) NOT NULL,
    vl_financiado         NUMBER(11, 2) NOT NULL,
    dt_concessao          DATE          NOT NULL,
    ds_finalidade_credito NUMBER(1)     NOT NULL, 
    dt_solicitacao        DATE          NULL
);

COMMENT ON COLUMN t_sp2_financiamento.ds_finalidade_credito IS
    'finalidade do crédito: 1 investimento, 2 custeio, 3 industrializacao ou 4 comercializacao';

    ALTER TABLE t_sp2_financiamento
ADD CONSTRAINT ck_sp2_financ_finalcred 
    CHECK ( ds_finalidade_credito IN ( 1, 2, 3, 4 ) );

    ALTER TABLE t_sp2_financiamento 
ADD CONSTRAINT ck_sp2_financ_area 
    CHECK ( qt_area_finaciada > 0 );

    ALTER TABLE t_sp2_financiamento 
ADD CONSTRAINT ck_sp2_financ_valor 
    CHECK ( vl_financiado > 0 );

    ALTER TABLE t_sp2_financiamento 
ADD CONSTRAINT ck_sp2_financ_dtconces 
    CHECK ( dt_concessao > dt_solicitacao );
    
    ALTER TABLE t_sp2_financiamento 
ADD CONSTRAINT pk_t_sp2_financiamento 
    PRIMARY KEY ( cd_financiamento, cd_fonte_recurso );


CREATE TABLE t_sp2_fonte_recurso (
    cd_fonte_recurso NUMBER(4)      NOT NULL,
    cd_programa      NUMBER(4)      NOT NULL,
    nm_fonte_recurso VARCHAR2(50)   NOT NULL,
    ds_fonte_recurso VARCHAR2(200)  NOT NULL
);

    ALTER TABLE t_sp2_fonte_recurso 
ADD CONSTRAINT pk_t_sp2_fonte_recurso 
    PRIMARY KEY ( cd_fonte_recurso );

    ALTER TABLE t_sp2_fonte_recurso 
ADD CONSTRAINT un_sp2_fonte_recurso_nome 
    UNIQUE ( nm_fonte_recurso );

CREATE TABLE t_sp2_modalidade (
    cd_modalidade     NUMBER(4)     NOT NULL,
    nm_modalidade     VARCHAR2(50)  NOT NULL,
    ds_modalidade     VARCHAR2(200) NOT NULL,
    ds_tipo_atividade NUMBER(4)     NOT NULL 
);

COMMENT ON COLUMN t_sp2_modalidade.nm_modalidade IS
    'Especifica a modalidade destinada ao crédito. Exemplos:  Lavoura, Estocagem; Aquisição de animais, Serviços profissionais técnicos,  Maquinas e equipamentos, etc.';

COMMENT ON COLUMN t_sp2_modalidade.ds_tipo_atividade IS
    'Tipo de atividades rurais: 1 Agricultura, 2 Pecuária, 3 Silvicultura e Manejo Florestal, 4 Agroindústria, 5 Atividades Ligadas ao Turismo Rural, 6 Atividades Relacionadas a Produtos Naturais ou 7 Atividades Diversificadas';

    ALTER TABLE t_sp2_modalidade
ADD CONSTRAINT ck_t_sp2_modalidade_1 
    CHECK ( ds_tipo_atividade IN ( 1, 2, 3, 4, 5, 6 ) );

    ALTER TABLE t_sp2_modalidade 
ADD CONSTRAINT pk_t_sp2_modalidade 
    PRIMARY KEY ( cd_modalidade );

CREATE TABLE t_sp2_pessoa_fisica (
    cd_solicitante     NUMBER(10)       NOT NULL,
    nr_cpf             NUMBER(11)       NOT NULL,
    nr_inscricao_rural NUMBER(13)       NOT NULL,
    dt_nasc            DATE             NOT NULL,
    ds_genero          CHAR(2)          NOT NULL,
    ds_estado_civil    CHAR(1)          NOT NULL,
    vl_renda_anual     NUMBER(11, 2)    NOT NULL
);

COMMENT ON COLUMN t_sp2_pessoa_fisica.ds_genero IS
    'Descrição de gereno será definido por M = Mulher, H = Homem ou NB = Não binário';

COMMENT ON COLUMN t_sp2_pessoa_fisica.ds_estado_civil IS
    'Descrição de estado civil será definido por S = Solteiro, C = Casado, D = Divorciado, V = Viuvo ou U = Uniao estável';

    ALTER TABLE t_sp2_pessoa_fisica
ADD CONSTRAINT ck_sp2_pfisica_gen 
    CHECK ( upper(ds_genero) = 'M' OR 
            upper(ds_genero) = 'H' OR 
            upper(ds_genero) = 'NB' );

    ALTER TABLE t_sp2_pessoa_fisica
ADD CONSTRAINT ck_sp2_pfisica_estcivil 
    CHECK ( upper(ds_estado_civil) = 'S' OR 
            upper(ds_estado_civil) = 'C' OR 
            upper(ds_estado_civil) = 'D' OR 
            upper(ds_estado_civil) = 'V' );

/*
   ALTER TABLE t_sp2_pessoa_fisica
ADD CONSTRAINT ck_sp2_pfisica_idade 
    CHECK ((sysdate - dt_nasc)>= 6575) );
Relatório de erros -
ORA-01735: opção ALTER TABLE é inválida
01735. 00000 -  "invalid ALTER TABLE option"
*/

    ALTER TABLE t_sp2_pessoa_fisica
ADD CONSTRAINT ck_sp2_pfisica_renda 
    CHECK ( vl_renda_anual >= 0
         AND vl_renda_anual <= 1600000000.00 );

    ALTER TABLE t_sp2_pessoa_fisica 
ADD CONSTRAINT pk_t_sp2_pessoa_fisica 
    PRIMARY KEY ( cd_solicitante );

    ALTER TABLE t_sp2_pessoa_fisica 
ADD CONSTRAINT un_sp2_pfisica_cpf 
    UNIQUE ( nr_cpf );

    ALTER TABLE t_sp2_pessoa_fisica 
ADD CONSTRAINT un_sp2_pfisica_insrural 
    UNIQUE ( nr_inscricao_rural );

CREATE TABLE t_sp2_pessoa_juridica (
    cd_solicitante   NUMBER(10)     NOT NULL,
    nr_cnpj          NUMBER(14)     NOT NULL,
    nm_fantasia      VARCHAR2(50)   NOT NULL,
    nr_insc_estadual NUMBER(15)     NULL,
    dt_fundacao      DATE           NOT NULL,
    vl_receita_anual NUMBER(11, 2)  NOT NULL
);

    ALTER TABLE t_sp2_pessoa_juridica
ADD CONSTRAINT ck_sp2_pjuridica_receita 
    CHECK ( vl_receita_anual >= 0
        AND vl_receita_anual <= 1600000000.00 );

    ALTER TABLE t_sp2_pessoa_juridica 
ADD CONSTRAINT pk_t_sp2_pessoa_juridica 
    PRIMARY KEY ( cd_solicitante );

    ALTER TABLE t_sp2_pessoa_juridica 
ADD CONSTRAINT un_sp2_pjuridica_cnpj 
    UNIQUE ( nr_cnpj );

CREATE TABLE t_sp2_produto (
    cd_produto    NUMBER(4)     NOT NULL,
    cd_modalidade NUMBER(4)     NOT NULL,
    nm_produto    VARCHAR2(50)  NOT NULL,
    ds_produto    VARCHAR2(200) NOT NULL
);

    ALTER TABLE t_sp2_produto 
ADD CONSTRAINT pk_t_sp2_produto 
    PRIMARY KEY ( cd_produto );

CREATE TABLE t_sp2_programa (
    cd_programa    NUMBER(4)        NOT NULL,
    nm_programa    VARCHAR2(50)     NOT NULL,
    ds_programa    VARCHAR2(200)    NOT NULL,
    ds_subprograma VARCHAR2(50)     NULL
);

    ALTER TABLE t_sp2_programa 
ADD CONSTRAINT pk_t_sp2_programa 
    PRIMARY KEY ( cd_programa );

    ALTER TABLE t_sp2_programa 
ADD CONSTRAINT un_sp2_programa_nome 
    UNIQUE ( nm_programa );

CREATE TABLE t_sp2_solicitante (
    cd_solicitante      NUMBER(10)      NOT NULL,
    nm_solicitante      VARCHAR2(70)    NOT NULL,
    ds_tipo_solicitante NUMBER(1)       NOT NULL,
    ds_endereco         VARCHAR2(200)   NOT NULL,
    ds_email            VARCHAR2(40)    NOT NULL
);

COMMENT ON COLUMN t_sp2_solicitante.ds_tipo_solicitante IS
    'Tipo de solicitante: 1 pessoa fisica ou 2 pessoa juridica';

    ALTER TABLE t_sp2_solicitante
ADD CONSTRAINT ck_sp2_solicitante_tipo 
    CHECK ( ds_tipo_solicitante IN ( 1, 2 ) );

    ALTER TABLE t_sp2_solicitante 
ADD CONSTRAINT pk_t_sp2_solicitante 
    PRIMARY KEY ( cd_solicitante );

    ALTER TABLE t_sp2_financiamento
ADD CONSTRAINT fk_sp2_financ_frecurso 
    FOREIGN KEY ( cd_fonte_recurso )
    REFERENCES t_sp2_fonte_recurso ( cd_fonte_recurso );

    ALTER TABLE t_sp2_financiamento
ADD CONSTRAINT fk_sp2_financ_produto 
    FOREIGN KEY ( cd_produto )
    REFERENCES t_sp2_produto ( cd_produto );

    ALTER TABLE t_sp2_financiamento
ADD CONSTRAINT fk_sp2_financ_solicitante 
    FOREIGN KEY ( cd_solicitante )
    REFERENCES t_sp2_solicitante ( cd_solicitante );

    ALTER TABLE t_sp2_fonte_recurso
ADD CONSTRAINT fk_sp2_frecurso_programa 
    FOREIGN KEY ( cd_programa )
    REFERENCES t_sp2_programa ( cd_programa );

    ALTER TABLE t_sp2_pessoa_fisica
ADD CONSTRAINT fk_sp2_pfisica_solicitante 
    FOREIGN KEY ( cd_solicitante )
    REFERENCES t_sp2_solicitante ( cd_solicitante );

    ALTER TABLE t_sp2_pessoa_juridica
ADD CONSTRAINT fk_sp2_pjuridica_solicitante 
    FOREIGN KEY ( cd_solicitante )
    REFERENCES t_sp2_solicitante ( cd_solicitante );

    ALTER TABLE t_sp2_produto
ADD CONSTRAINT fk_sp2_produto_modalidade 
    FOREIGN KEY ( cd_modalidade )
    REFERENCES t_sp2_modalidade ( cd_modalidade );
    
    
    COMMIT;